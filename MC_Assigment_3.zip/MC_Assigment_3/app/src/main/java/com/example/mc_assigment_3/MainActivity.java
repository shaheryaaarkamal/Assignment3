package com.example.mc_assigment_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RadioGroup radioGroup;
    RadioButton radioButton;
    TextView textView;
    private ArrayList<String> array=new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        radioGroup = findViewById(R.id.radioGroup);
        textView = findViewById(R.id.textViewResults);
    }

    public void ShowSelection(View view) {

        int checked = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(checked);
        textView.setText(radioButton.getText());

    }
    public void PutInArray(View view){
        boolean checked=((CheckBox) view).isChecked();
        switch(view.getId())
        {
            case R.id.checkBox1:
            {
                if(checked)
                {
                    array.add("1st checkbox selected");
                }
                else
                {
                    array.remove("1st checkbox selected");
                }
                break;
            }
            case R.id.checkBox2:
            {
                if(checked)
                {
                    array.add("2nd checkbox selected");
                }
                else
                {
                    array.remove("2nd checkbox selected");
                }
                break;
            }
            case R.id.checkBox3:
            {
                if(checked)
                {
                    array.add("3rd checkbox selected");
                }
                else
                {
                    array.remove("3rd checkbox selected");
                }
                break;
            }
            case R.id.checkBox4:
            {
                if(checked)
                {
                    array.add("4th checkbox selected");
                }
                else
                {
                    array.remove("4th checkbox selected");
                }
                break;
            }
        }
    }

    public void PassDataOnNextActivity(View view){
        Intent i=new Intent(MainActivity.this,MainActivity2.class);
        i.putExtra("array",array);
        startActivity(i);
    }
}